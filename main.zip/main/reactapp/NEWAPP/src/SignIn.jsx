import React, { useState } from 'react';
import axios from 'axios';
import { Link, useNavigate } from 'react-router-dom';
import "./SignIn.css";

function SignIn({ setIsLoggedIn }) {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState(null);
    const [role, setRole] = useState('User');
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError(null);
        try {

            // if( i want to add an validation if the RadioRole is user call this api and for other call another)
            let response;
            if (role === 'User' || role === null) {

                response = await axios.post("http://localhost:8080/login/signin", { email, password });
                if (response.data.mesg === "USER") {
                    console.log(response.data)
    
                    navigate('/');
                } else {
                    navigate('/admin');
                }
            } else if (role === 'Manager') {
                console.log("in manager axios call....")
                response = await axios.post("http://localhost:8080/login/signin/manager", { email, password });
                navigate('/manager');
            } else if (role === 'Delivery') {
                response = await axios.post("http://localhost:8080/login/signin/delivery", { email, password });
                navigate('/delivery');
            }

            sessionStorage.setItem('jwt', response.data.jwt);
            sessionStorage.setItem('id', response.data.id);
            sessionStorage.setItem('role', response.data.mesg);
            sessionStorage.setItem('img', response.data.img);
            // sessionStorage.setItem('img', response.data.imgUrl);

            // Update the isLoggedIn state to true
            setIsLoggedIn(true);

            
        } catch (err) {
            console.log(err.response ? err.response.data : err.message);
            setError('Invalid email or password');
        }
    };

    return (
        <div className="container">
            <div className="signinsection row d-flex">
                <div className="col-10 signinleft justify-content-center">
                    <div className="loginSignupHeading">
                        <h2>Sign In</h2>
                    </div>
                    <form onSubmit={handleSubmit}>
                        <div className="loginGroup">
                            <label htmlFor="emailAddress" className="form-label">Email Address</label>
                            <input
                                type="email"
                                className="form-control"
                                id="emailAddress"
                                placeholder="Email Address"
                                name="emailAddress"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                required
                            />
                        </div>
                        <div className="loginGroup mb-4">
                            <label htmlFor="password" className="form-label">Password</label>
                            <div className="input-group">
                                <input
                                    type="password"
                                    className="form-control"
                                    id="passwordField"
                                    placeholder="Password"
                                    name="password"
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                />
                                <span className="inputGroupText passwordShow">
                                    <i className="fa-regular fa-eye field-icon togglePassword" toggle="#passwordField"></i>
                                </span>
                            </div>
                            <div className='mt-4'>
                                <div className="form-check form-check-inline">
                                    <input className="form-check-input" type="radio" onChange={(e) => setRole(e.target.value)} name="RadioRole" id="R1" value="User" />
                                    <label className="form-check-label" for="R1">User</label>
                                </div>
                                <div className="form-check form-check-inline">
                                    <input className="form-check-input" type="radio" onChange={(e) => setRole(e.target.value)} name="RadioRole" id="R2" value="Manager"/>
                                    <label className="form-check-label" for="R2">Manager</label>
                                </div>
                                <div className="form-check form-check-inline">
                                    <input className="form-check-input" type="radio" onChange={(e) => setRole(e.target.value)} name="RadioRole" id="R3" value="Delivery" />
                                    <label className="form-check-label" for="R3">Delivery Boy</label>
                                </div>
                            </div>
                        </div>
                        {error && <div className="error">{error}</div>}
                        <button type="submit" className="btn loginSignupBtn btn-success">Sign In</button>
                    </form>
                    <p>Don't have an account? <Link to="/signup">SignUp</Link></p>
                </div>
                <div className="col-2 signinright">
                    <center>
                        <div className="loginTab">
                            <Link to="/signup">
                                <svg xmlns="http://www.w3.org/2000/svg" width="62" height="62" viewBox="0 0 62 62" fill="none">
                                    <path
                                        d="M8.28655 50.4999C12.1437 41.7142 20.7151 35.4999 31.0008 35.4999C41.2866 35.4999 50.0723 41.7142 53.7151 50.4999M61 31C61 47.5685 47.5685 61 31 61C14.4315 61 1 47.5685 1 31C1 14.4315 14.4315 1 31 1C47.5685 1 61 14.4315 61 31ZM41.7143 24.5714C41.7143 30.4888 36.9173 35.2857 31 35.2857C25.0827 35.2857 20.2857 30.4888 20.2857 24.5714C20.2857 18.6541 25.0827 13.8571 31 13.8571C36.9173 13.8571 41.7143 18.6541 41.7143 24.5714Z"
                                        stroke="white" strokeWidth="2" strokeMiterlimit="10" strokeLinecap="round"
                                        strokeLinejoin="round" />
                                </svg>
                                <div>Sign Up</div>
                            </Link>
                        </div>
                    </center>
                </div>
            </div>
        </div>
    );
}

export default SignIn;

