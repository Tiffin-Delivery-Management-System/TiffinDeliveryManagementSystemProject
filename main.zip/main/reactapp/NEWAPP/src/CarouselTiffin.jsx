import './CarouselTiffin.css';

function CarouselTiffin() {
    return (
        <>
            <div id="carousel" className="carousel slide" data-bs-ride="carousel">
                <div className="carousel-indicators">
                    <button type="button" data-bs-target="#carousel" data-bs-slide-to="0" className="active" aria-current="true" aria-label="Slide 1"></button>
                    <button type="button" data-bs-target="#carousel" data-bs-slide-to="1" aria-label="Slide 2"></button>
                    <button type="button" data-bs-target="#carousel" data-bs-slide-to="2" aria-label="Slide 3"></button>
                </div>
                <div className="carousel-inner">
                    <div className="carousel-item active" id="carousel1">
                        {/* <img src="./images/carousel1.jpg" className="d-block w-100" alt="..." /> */}
                            <div className="carousel-caption d-none d-md-block">
                                <h5>Freshness Delivered Daily</h5>
                                <p>Your diet is a bank account. Good food choices are good investments.</p>
                            </div>
                    </div>
                    <div className="carousel-item" id="carousel2">
                        {/* <img src="./images/carousel2.jpg" className="d-block w-100" alt="..." /> */}
                            <div className="carousel-caption d-none d-md-block">
                                <h5>Health is Wealth</h5>
                                <p>It is health tha is real wealth and not pieces of gold and silver.</p>
                            </div>
                    </div>
                    <div className="carousel-item" id="carousel3">
                        {/* <img src="./images/carousel3.jpg" className="d-block w-100" alt="..." /> */}
                            <div className="carousel-caption d-none d-md-block">
                                <h5>Fuel Your Life</h5>
                                <p>Tell me what you eat, and I will tell you who you are.</p>
                            </div>
                    </div>
                </div>
                <button className="carousel-control-prev" type="button" data-bs-target="#carousel" data-bs-slide="prev">
                    <span className="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span className="visually-hidden">Previous</span>
                </button>
                <button className="carousel-control-next" type="button" data-bs-target="#carousel" data-bs-slide="next">
                    <span className="carousel-control-next-icon" aria-hidden="true"></span>
                    <span className="visually-hidden">Next</span>
                </button>
            </div>
        </>
    );
};

export default CarouselTiffin;