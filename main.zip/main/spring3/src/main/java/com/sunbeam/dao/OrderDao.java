package com.sunbeam.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.sunbeam.entities.Order;

public interface OrderDao extends JpaRepository<Order, Long> {
	List<Order> findByUserUserId(Long id);
	@Query("SELECT COUNT(o) FROM Order o")
    long countAllOrders();
	@Query("SELECT SUM(o.totalPrice) FROM Order o")
	Double calculateTotalRevenue();
	
	////////////////// for manager ///////////////////////////
	@Modifying
    @Query("UPDATE Order o SET o.status = :status WHERE o.orderId = :orderId")
    int updateOrderStatus(@Param("status") String status, @Param("orderId") Long orderId);
	@Query("SELECT COUNT(o) FROM Order o Where o.tiffinServiceId = :tiffinServiceId")
    long countAllOrdersForManager(Long tiffinServiceId);
	@Query("SELECT SUM(o.totalPrice) FROM Order o Where o.tiffinServiceId = :tiffinServiceId")
	Double calculateTotalRevenueForManager(Long tiffinServiceId);
	
}
