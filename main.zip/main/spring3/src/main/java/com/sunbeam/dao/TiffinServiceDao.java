package com.sunbeam.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sunbeam.entities.TiffinService;

public interface TiffinServiceDao extends JpaRepository<TiffinService, Long> {
	Optional<TiffinService> findByServiceName(String serviceName);
	Optional<TiffinService> findByServiceEmail(String serviceEmail);
}
