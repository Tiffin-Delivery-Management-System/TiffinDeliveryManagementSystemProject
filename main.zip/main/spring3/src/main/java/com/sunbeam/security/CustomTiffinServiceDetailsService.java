package com.sunbeam.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sunbeam.entities.TiffinService;
import com.sunbeam.dao.TiffinServiceDao;  // Make sure you have a corresponding DAO

@Service
@Transactional
public class CustomTiffinServiceDetailsService implements UserDetailsService {
    @Autowired
    private TiffinServiceDao tiffinServiceDao;

    @Override
    public UserDetails loadUserByUsername(String serviceEmail) throws UsernameNotFoundException {
        TiffinService tiffinService = tiffinServiceDao.findByServiceEmail(serviceEmail)
                .orElseThrow(() -> new UsernameNotFoundException("Tiffin Service not found with service email: " + serviceEmail));
        return new CustomTiffinServiceDetails(tiffinService);
    }
}
