package com.sunbeam.security;

import java.util.Collection;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.sunbeam.entities.TiffinService;

public class CustomTiffinServiceDetails implements UserDetails {
	private TiffinService tiffinService;

    public CustomTiffinServiceDetails(TiffinService tiffinService) {
        this.tiffinService = tiffinService;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return List.of(new SimpleGrantedAuthority("ROLE_MANAGER"));
    }

    @Override
    public String getPassword() {
        return tiffinService.getServicePassword();
    }

    @Override
    public String getUsername() {
        return tiffinService.getServiceName();
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }
}
