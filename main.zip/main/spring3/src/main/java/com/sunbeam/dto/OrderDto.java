package com.sunbeam.dto;

public class OrderDto {

    private Long orderId;
    private UserDto user; 
    private Double totalPrice;
    private String tiffins; // Updated to String
    private String status = "PREPARING";
    private Long tiffinServiceId;

    public Long getTiffinServiceId() {
		return tiffinServiceId;
	}

	public void setTiffinServiceId(Long tiffinServiceId) {
		this.tiffinServiceId = tiffinServiceId;
	}

	public OrderDto(){
    	
    }

	public OrderDto(Long orderId, UserDto user, Double totalPrice, String tiffins, String status,
			Long tiffinServiceId) {
		super();
		this.orderId = orderId;
		this.user = user;
		this.totalPrice = totalPrice;
		this.tiffins = tiffins;
		this.status = status;
		this.tiffinServiceId = tiffinServiceId;
	}

	@Override
	public String toString() {
		return "OrderDto [orderId=" + orderId + ", user=" + user + ", totalPrice=" + totalPrice + ", tiffins=" + tiffins
				+ ", status=" + status + ", tiffinServiceId=" + tiffinServiceId + "]";
	}

	// Getters and Setters
    public Long getOrderId() {
        return orderId;
    }

    public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public UserDto getUser() {
        return user;
    }

    public void setUser(UserDto user) {
        this.user = user;
    }

    public Double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(Double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public String getTiffins() {
        return tiffins;
    }

    public void setTiffins(String tiffins) {
        this.tiffins = tiffins;
    }
}