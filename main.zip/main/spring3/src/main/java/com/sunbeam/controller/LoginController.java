package com.sunbeam.controller;

import java.util.Base64;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sunbeam.dao.TiffinServiceDao;
import com.sunbeam.dao.UserDao;
import com.sunbeam.dto.SigninRequest;
import com.sunbeam.dto.SigninResponse;
import com.sunbeam.dto.UserDto;
import com.sunbeam.entities.TiffinService;
import com.sunbeam.entities.User;
import com.sunbeam.security.JwtUtils;
import com.sunbeam.service.TiffinServiceService;
import com.sunbeam.service.UserService;


@RestController
@RequestMapping("/login")
public class LoginController {
@Autowired
private UserService userService;
@Autowired
private TiffinServiceDao tiffinServiceDao;
@Autowired
private AuthenticationManager authMgr;
@Autowired
private JwtUtils jwtUtils;
@Autowired
private UserDao udao;
@CrossOrigin(origins = "http://localhost:3000")
@PostMapping("/signin")
public ResponseEntity<?> authenticateUser(@RequestBody @Valid SigninRequest request) {
	System.out.println("in sign in" + request);
	//create a token(implementation of Authentication i/f)
	//to store un verified user email n pwd
	UsernamePasswordAuthenticationToken token=new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword());
	//invoke auth mgr's authenticate method;
	Authentication verifiedToken = authMgr.authenticate(token);
	//=> authentication n authorization  successful !
	System.out.println(verifiedToken.getPrincipal().getClass());//custom user details object
	//create JWT n send it to the clnt in response
	User user1 = udao.findByEmail(request.getEmail()).orElseThrow();
	String base64Image=Base64.getEncoder().encodeToString(user1.getUserImage());
	SigninResponse resp=new SigninResponse(jwtUtils.generateJwtToken(verifiedToken),user1.getRole().name(), user1.getUserId(),base64Image);
	System.out.println(resp.getId());
	return ResponseEntity.
			status(HttpStatus.CREATED).body(resp);
}

@CrossOrigin(origins = "http://localhost:3000")
@PostMapping("/signin/manager")
public ResponseEntity<?> authenticateManager(@RequestBody @Valid SigninRequest request) {
    try {
        // Create a token for authentication
        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken(
                request.getEmail(), request.getPassword());
        System.out.println("Authenticating Manager with token: " + token);
        
        // Authenticate the user
        Authentication verifiedToken = authMgr.authenticate(token);
        System.out.println("Verified token: " + verifiedToken);
        
        // Find the Tiffin Service by email or other identifier
        TiffinService tiffinService = tiffinServiceDao.findByServiceEmail(request.getEmail())
                .orElseThrow(() -> new RuntimeException("Service not found with email: " + request.getEmail()));
        
        // Ensure correct image encoding
        byte[] imageBytes = tiffinService.getServiceImagePath();
        String base64Image = (imageBytes != null) ? Base64.getEncoder().encodeToString(imageBytes) : null;
        
        // Create response object
        SigninResponse resp = new SigninResponse(jwtUtils.generateJwtToken(verifiedToken), 
                                                 "MANAGER", 
                                                 tiffinService.getServiceId(), 
                                                 base64Image);
        
        // Return the response entity
        return ResponseEntity.status(HttpStatus.CREATED).body(resp);
    } catch (AuthenticationException e) {
    	e.printStackTrace();
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials or user type.");
    } catch (Exception e) {
    	e.printStackTrace();
        e.printStackTrace(); // Log the exception for debugging
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("An error occurred during login.");
    }
}



	
@CrossOrigin(origins = "http://localhost:3000")
	@PostMapping("/signin/delivery")
	public ResponseEntity<?> authenticateDelivery(@RequestBody @Valid SigninRequest request){
		return ResponseEntity.status(HttpStatus.CREATED).body("Requested deliver data found");
	}
}
