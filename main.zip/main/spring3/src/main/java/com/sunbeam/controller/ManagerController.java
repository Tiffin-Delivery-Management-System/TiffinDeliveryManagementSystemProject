package com.sunbeam.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.sunbeam.dto.OrderDto;
import com.sunbeam.dto.TiffinServiceDto;
import com.sunbeam.entities.Order;
import com.sunbeam.entities.TiffinService;
import com.sunbeam.service.OrderService;
import com.sunbeam.service.TiffinService1;
import com.sunbeam.service.TiffinServiceService;

import java.io.IOException;
import java.util.Base64;
import java.util.List;

@RestController
@RequestMapping("/manager")
public class ManagerController {

    @Autowired
    private TiffinService1 tiffinService1;
    
    @Autowired TiffinServiceService tiffinServiceService;
    
    @Autowired
    private OrderService orderService;

    @CrossOrigin("*")
    @PostMapping("/addtiffin")
    public ResponseEntity<String> addTiffin(
            @RequestParam("name") String name,
            @RequestParam("price") double price,
            @RequestParam("description") String description,
            @RequestParam("image") MultipartFile image,
            @RequestParam("tiffinServiceId") Long tiffinServiceId) {

        try {
            byte[] imageBytes = image.getBytes();

            tiffinService1.saveTiffin(name, price, description, imageBytes, tiffinServiceId);

            return ResponseEntity.ok("Tiffin added successfully.");
        } catch (IOException e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to add tiffin.");
        }
    }// end of add tiffin method
    
    @CrossOrigin("*")
    @GetMapping("/{mid}")
    public ResponseEntity<?> getTiffinServiceById(@PathVariable Long mid){
    	try {
    		TiffinServiceDto ts = tiffinServiceService.getManagerDetails(mid);
    		System.out.println("The tiffinService is - "+ts);
    		return ResponseEntity.ok(ts);
    	}catch(Exception e) {
    		e.printStackTrace();
    		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
    	}
    }
    
    @CrossOrigin("*")
    @GetMapping("/orders/{managerId}")
    public ResponseEntity<?> getOrdersOfManager(@PathVariable Long managerId){
    	System.out.println("In get Orders of manager");
    	try {
    		List<OrderDto> orders= orderService.getManagerOrders(managerId);
    		System.out.println("-----Preparing orders for Manager--------");
    		orders.forEach(e -> System.out.println(e));
    		System.out.println("-------------");
    		return ResponseEntity.ok(orders);
    	}catch(Exception e) {
    		e.printStackTrace();
    		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Can't get orders of This tiffinService");
    	}
    }
    
    @CrossOrigin("*")
    @GetMapping("/ordersprepared/{managerId}")
    public ResponseEntity<?> getPreparedOrdersForManager(@PathVariable Long managerId){
    	System.out.println("In get Orders of manager");
    	try {
    		List<OrderDto> orders= orderService.getManagerOrdersPrepared(managerId);
    		System.out.println("------Delivery orders for manager-------");
    		orders.forEach(e -> System.out.println(e));
    		System.out.println("-------------");
    		return ResponseEntity.ok(orders);
    	}catch(Exception e) {
    		e.printStackTrace();
    		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Can't get orders of This tiffinService");
    	}
    }
    
    @CrossOrigin("*")
    @PutMapping("/updateorder")
    public ResponseEntity<?> updateOrderFromPreparingToDelivery(@RequestBody OrderDto dto){
    	try {
    		System.out.println("In update order from preparing to Delivery");
    		orderService.updateOrderForManager(dto.getOrderId());
    		return ResponseEntity.ok("Sucessfully given to delivery...");
    	}catch(Exception e) {
    		e.printStackTrace();
    		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Can't update order");
    	}
    }
    
    @CrossOrigin("*")
    @GetMapping("/totalOrders/{managerId}")
    public ResponseEntity<?> getTotalOrdersPlaced(@PathVariable Long managerId){
    	try {
    		Long nos = orderService.getTotalNumberOfOrders(managerId);
    		System.out.println("The total orders till now are - "+nos);
    		return ResponseEntity.ok(nos);
    	}catch(Exception e) {
    		e.printStackTrace();
    		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
    	}
    }
    
    @CrossOrigin("*")
    @GetMapping("/totalRevenue/{managerId}")
    public ResponseEntity<?> getTotalRevenue(@PathVariable Long managerId){
    	try {
    		Double total = orderService.getRevenueOfTiffinService(managerId);
    		System.out.println("The Revenue till now is - "+total);
    		return ResponseEntity.ok(total);
    	}catch(Exception e) {
    		e.printStackTrace();
    		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
    	}
    }
    
}