package com.sunbeam.security;

import java.security.Key;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class JwtUtils {

	@Value("${SECRET_KEY}")
	private String jwtSecret;

	@Value("${EXP_TIMEOUT}")
	private int jwtExpirationMs;
	
	
	private Key key;

	@PostConstruct
	public void init() {
		key = Keys.hmacShaKeyFor(jwtSecret.getBytes());
	}

	// will be invoked by Authentication controller) , upon successful
	// authentication
	public String generateJwtToken(Authentication authentication) {
	    Object principal = authentication.getPrincipal();
	    String subject;
	    String authorities;

	    if (principal instanceof CustomUserDetails) {
	        CustomUserDetails userPrincipal = (CustomUserDetails) principal;
	        subject = userPrincipal.getUsername();
	        authorities = getAuthoritiesInString(userPrincipal.getAuthorities());
	    } else if (principal instanceof CustomTiffinServiceDetails) {
	        CustomTiffinServiceDetails tiffinServicePrincipal = (CustomTiffinServiceDetails) principal;
	        subject = tiffinServicePrincipal.getUsername();
	        authorities = getAuthoritiesInString(tiffinServicePrincipal.getAuthorities());
	    } else {
	        throw new IllegalArgumentException("Unsupported principal type");
	    }

	    return Jwts.builder()
	            .setSubject(subject)
	            .setIssuedAt(new Date())
	            .setExpiration(new Date((new Date()).getTime() + jwtExpirationMs))
	            .claim("authorities", authorities)
	            .signWith(key, SignatureAlgorithm.HS512)
	            .compact();
	}

	// this method will be invoked by our custom JWT filter
	public String getUserNameFromJwtToken(Claims claims) {
		return claims.getSubject();
	}

	// this method will be invoked by our custom filter
	public Claims validateJwtToken(String jwtToken) {
		// try {
		Claims claims = Jwts.parserBuilder()
				.setSigningKey(key).build().
		// Sets the signing key used to verify JWT digital signature.
				parseClaimsJws(jwtToken).getBody();// Parses the signed JWT returns the resulting Jws<Claims> instance
		// throws exc in case of failures in verification
		return claims;		
	}
	// Accepts Collection<GrantedAuthority> n rets comma separated list of it's
	// string form

	private String getAuthoritiesInString(Collection<? extends GrantedAuthority> authorities) {
		String authorityString = authorities.stream().
				map(authority -> authority.getAuthority())
				.collect(Collectors.joining(","));
		System.out.println(authorityString);
		return authorityString;
	}

	public List<GrantedAuthority> getAuthoritiesFromClaims(Claims claims) {
		String authString = (String) claims.get("authorities");
		List<GrantedAuthority> authorities = AuthorityUtils.commaSeparatedStringToAuthorityList(authString);
		authorities.forEach(System.out::println);
		return authorities;
	}

}