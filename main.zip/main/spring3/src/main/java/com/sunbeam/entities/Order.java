package com.sunbeam.entities;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "orders")
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long orderId;
    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    @JsonBackReference
    private User user;
    @Column(nullable = false, updatable = false)
    @org.hibernate.annotations.CreationTimestamp
    private LocalDateTime orderTime;
    @Column(nullable = false)
    private Double totalPrice;
    private String tiffins;
    @Column(nullable = false)
    private String status = "PREPARING";    
    @Column(name = "tiffin_service_id",nullable = false)
    private Long tiffinServiceId;
    
    // Default constructor 
    public Order() {}

    // Parameterized constructor
    public String getStatus() {
        return status;
    }

    @Override
	public String toString() {
		return "Order [orderId=" + orderId + ", user=" + user + ", orderTime=" + orderTime + ", totalPrice="
				+ totalPrice + ", tiffins=" + tiffins + ", status=" + status + ", tiffinServiceId=" + tiffinServiceId
				+ "]";
	}

	public Order(Long orderId, User user, LocalDateTime orderTime, Double totalPrice, String tiffins,
			String status, Long tiffinServiceId) {
		super();
		this.orderId = orderId;
		this.user = user;
		this.orderTime = orderTime;
		this.totalPrice = totalPrice;
		this.tiffins = tiffins;
		this.status = status;
		this.tiffinServiceId = tiffinServiceId;
	}

	public Long getTiffinServiceId() {
		return tiffinServiceId;
	}

	public void setTiffinServiceId(Long tiffinServiceId) {
		this.tiffinServiceId = tiffinServiceId;
	}

	public void setStatus(String status) {
        this.status = status;
    }

    // Getters and Setters
    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public LocalDateTime getOrderTime() {
        return orderTime;
    }

    public void setOrderTime(LocalDateTime orderTime) {
        this.orderTime = orderTime;
    }

    public Double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(Double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public String getTiffins() {
        return tiffins;
    }

    public void setTiffins(String tiffins) {
        this.tiffins = tiffins;
    }
}
