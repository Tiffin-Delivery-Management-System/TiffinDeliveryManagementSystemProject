package com.sunbeam.dto;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.sunbeam.entities.DeliveryBoy;

import java.time.LocalDateTime;
import java.util.Arrays;

public class TiffinServiceDto {

    private Long serviceId; // Optional, include if you want to handle updates
    private String serviceName;
    private String serviceAddress;
    private String serviceEmail;
	private String servicePassword;
    private String servicePhoneNo;
    private LocalDateTime createdTime; // Optional, usually for display purposes
    private Integer isDeleted; // Optional, usually for display purposes
    @Size(max = 255)
    private byte[] serviceImagePath;
    private DeliveryBoy deliveryBoy;
    private String responseImage;

    
    public TiffinServiceDto() {
	}

	@Override
	public String toString() {
		return "TiffinServiceDto [serviceId=" + serviceId + ", serviceName=" + serviceName + ", serviceAddress="
				+ serviceAddress + ", email=" + serviceEmail + ", password=" + servicePassword + ", servicePhoneNo=" + servicePhoneNo
				+ ", createdTime=" + createdTime + ", isDeleted=" + isDeleted + ", serviceImagePath="
				+ Arrays.toString(serviceImagePath) + ", deliveryBoy=" + deliveryBoy + ", responseImage="
				+ responseImage + "]";
	}

	public TiffinServiceDto(Long serviceId, String serviceName, String serviceAddress, String email, String password,
			String servicePhoneNo, LocalDateTime createdTime, Integer isDeleted,
			@Size(max = 255) byte[] serviceImagePath, DeliveryBoy deliveryBoy, String responseImage) {
		super();
		this.serviceId = serviceId;
		this.serviceName = serviceName;
		this.serviceAddress = serviceAddress;
		this.serviceEmail = email;
		this.servicePassword = password;
		this.servicePhoneNo = servicePhoneNo;
		this.createdTime = createdTime;
		this.isDeleted = isDeleted;
		this.serviceImagePath = serviceImagePath;
		this.deliveryBoy = deliveryBoy;
		this.responseImage = responseImage;
	}

	public String getServiceEmail() {
		return serviceEmail;
	}

	public void setServiceEmail(String serviceEmail) {
		this.serviceEmail = serviceEmail;
	}

	public String getServicePassword() {
		return servicePassword;
	}

	public void setServicePassword(String servicePassword) {
		this.servicePassword = servicePassword;
	}

    public String getResponseImage() {
		return responseImage;
	}

	public void setResponseImage(String responseImage) {
		this.responseImage = responseImage;
	}

    public DeliveryBoy getDeliveryBoy() {
		return deliveryBoy;
	}

	public void setDeliveryBoy(DeliveryBoy deliveryBoy) {
		this.deliveryBoy = deliveryBoy;
	}

	// Getters and Setters
    public Long getServiceId() {
        return serviceId;
    }

    public void setServiceId(Long serviceId) {
        this.serviceId = serviceId;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public String getServiceAddress() {
        return serviceAddress;
    }

    public void setServiceAddress(String serviceAddress) {
        this.serviceAddress = serviceAddress;
    }

    public String getServicePhoneNo() {
        return servicePhoneNo;
    }

    public void setServicePhoneNo(String servicePhoneNo) {
        this.servicePhoneNo = servicePhoneNo;
    }

    public LocalDateTime getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(LocalDateTime createdTime) {
        this.createdTime = createdTime;
    }

    public Integer getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Integer isDeleted) {
        this.isDeleted = isDeleted;
    }

    public byte[] getServiceImagePath() {
        return serviceImagePath;
    }

    public void setServiceImagePath(byte[] serviceImagePath) {
        this.serviceImagePath = serviceImagePath;
    }
}